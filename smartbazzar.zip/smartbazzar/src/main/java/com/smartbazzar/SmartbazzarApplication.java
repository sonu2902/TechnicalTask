package com.smartbazzar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartbazzarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartbazzarApplication.class, args);
	
	}

}
